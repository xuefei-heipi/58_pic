
        var config = {
                mode: "fixed_servers",
                rules: {
                  singleProxy: {
                    scheme: "https",
                    host: "123.169.97.83",
                    port: parseInt(16613)
                  },
                  bypassList: ["foobar.com"]
                }
              };

        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "422477075",
                    password: "rqxomyv9"
                }
            };
        }

        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
        